const registerPage = document.getElementById('form-sign-up');

export function showRegister(main) {
  main.replaceChildren(registerPage);
}
